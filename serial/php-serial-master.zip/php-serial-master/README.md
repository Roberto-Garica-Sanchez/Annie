php-serial
==========

This PHP class can be used to communicate with a serial port under Linux, OSX or Windows.

This code is from http://code.google.com/p/php-serial/ I just wanted to be able to use composer to install and use it.